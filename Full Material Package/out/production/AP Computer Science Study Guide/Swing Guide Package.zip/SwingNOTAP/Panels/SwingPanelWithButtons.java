package SwingNOTAP.Panels;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * An example of subclassing a JPanel and adding components to it.
 *
 * This is how gridx and gridy work
 *
 * (0, 0) (1, 0)
 * (0, 1) (1, 1)
 * (0, 2) (1, 2)
 * etc, etc
 * Where each (x, y) represents a component / where it should be placed.
 */
public class SwingPanelWithButtons extends JPanel {

    private Color selectedColor;

    public SwingPanelWithButtons() {
        selectedColor = Color.RED;
        initComponents();
    }

    private void initComponents() {
        //Create all the buttons and set backgrounds, AND add actionListeners that direct to private methods below for
        //organization.
        redButton = new Button();
        redButton.setBackground(Color.RED);
        redButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                redButtonClicked(e);
            }
        });

        blueButton = new Button();
        blueButton.setBackground(Color.BLUE);
        blueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                blueButtonClicked(e);
            }
        });

        orangeButton = new Button();
        orangeButton.setBackground(Color.ORANGE);
        orangeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                orangeButtonClicked(e);
            }
        });

        greenButton = new Button();
        greenButton.setBackground(Color.GREEN);
        greenButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                greenButtonClicked(e);
            }
        });

        yellowButton = new Button();
        yellowButton.setBackground(Color.YELLOW);
        yellowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                yellowButtonClicked(e);
            }
        });

        whiteButton = new Button();
        whiteButton.setBackground(Color.WHITE);
        whiteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                whiteButtonClicked(e);
            }
        });

        //Set all button sizes to 50 x 150.
        Button[] buttons = {redButton, blueButton, orangeButton, greenButton, yellowButton, whiteButton};
        for(Button button: buttons) {
            button.setPreferredSize(new Dimension(50, 150));
        }

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(whiteButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(yellowButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(greenButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        add(orangeButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(blueButton, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        add(redButton, gbc);

    }

    public Color getSelectedColor() {
        return selectedColor;
    }

    private void whiteButtonClicked(ActionEvent e) {
        selectedColor = Color.WHITE;
    }

    private void yellowButtonClicked(ActionEvent e) {
        selectedColor = Color.YELLOW;
    }

    private void greenButtonClicked(ActionEvent e) {
        selectedColor = Color.GREEN;
    }

    private void orangeButtonClicked(ActionEvent e) {
        selectedColor = Color.ORANGE;
    }

    private void blueButtonClicked(ActionEvent e) {
        selectedColor = Color.BLUE;
    }

    private void redButtonClicked(ActionEvent e) {
        selectedColor = Color.RED;
    }

    private Button redButton;
    private Button blueButton;
    private Button orangeButton;
    private Button greenButton;
    private Button yellowButton;
    private Button whiteButton;
}

