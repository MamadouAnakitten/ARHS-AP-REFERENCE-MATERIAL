package SwingNOTAP;

import SwingNOTAP.Frames.BorderFrame;
import SwingNOTAP.Frames.GridBagFrame;
import SwingNOTAP.Frames.SimpleFrame;

import java.awt.*;

/**
 * Example of how to run with swings and implement them to be effective for your purposes.
 *
 * Erase comments to see bFrame come to life!
 */
public class SwingExampleMain {

    GridBagFrame gFrame;
    SimpleFrame sFrame;
    BorderFrame bFrame;

    public SwingExampleMain() {
        gFrame = new GridBagFrame();
        gFrame.setVisible(true);

        //bFrame = new BorderFrame();
        //bFrame.setVisible(true);

        //sFrame = new SimpleFrame();
        //sFrame.setVisible(true);
        //runSFrameLoop();
    }

    /**
     * This method implements the use of interactivity in panels.
     */
    public void runLoop() {
        try{
            while(!gFrame.getSelectedColor().equals(Color.BLUE)){
                gFrame.setMainPanelColor(gFrame.getSelectedColor());
            }

            System.out.println("Loop Done!");

        } catch (NullPointerException ex) {

        }
    }

    private void runSFrameLoop() {
        for(int i = 0; i < 10000; i++) {
            sFrame.repaint();
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        SwingExampleMain test = new SwingExampleMain();
        test.runLoop();
    }
}
