package SwingNOTAP.Frames;

import SwingNOTAP.Panels.SwingPanelWithButtons;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * This is an example of subclassing the Java JFrame to utilize the full potential of Swing. This class shows a bit more
 * complexity in swing programming and any questions you might have would be happily answered by asking me in class, writing me
 * at richardkimhogans@gmail.com, or writing in the CP3 forum!
 */
public class GridBagFrame extends JFrame {
    private SwingPanelWithButtons buttonPanel;
    private JPanel mainPanel;

    public GridBagFrame() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        buttonPanel = new SwingPanelWithButtons();

        mainPanel = new JPanel();

        /*
        * You can also add listeners to pure components (components that aren't manually subclassed) by calling the
        * addMouseListener function and then giving a new MouseListener as an argument. You can then put code here, or
        * make these methods call other methods that you write, like I will below.
        *
        * You will see me implement this in the PanelWithButtons class.
        * */
        mainPanel.addMouseListener(new MouseListener() {
            public void mouseClicked(MouseEvent e) {
                //TODO Implement if you want to.
            }

            public void mousePressed(MouseEvent e) {
                mainPanelClicked(e);
            }

            public void mouseReleased(MouseEvent e) {
                //TODO Implement if you want to.
            }

            public void mouseEntered(MouseEvent e) {
                //TODO Implement if you want to.
            }

            public void mouseExited(MouseEvent e) {
                //TODO Implement if you want to.
            }
        });
        mainPanel.setPreferredSize(new Dimension(300, 300));

         /*
         * There are many different layouts for Java, with GridBag, and any custom being the most flexible.
         * I will show how I will utilize the Grid Bag layout below with comments.
         * */
        setLayout(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();


        /*
        * Feel free to look at the Javadocs for GridBagConstraints at: https://docs.oracle.com/javase/7/docs/api/java/awt/GridBagConstraints.html
        * and see what you can do with placement and configuration!
        *
        * Below you can see I put the two components next to each other in the positive x-axis of the grid. I then set an
        * inset, which is a horizontal and vertical spacer to 5 on all sides of the mainPanel. There is much you can do with
        * all the different layouts in java. Or you can opt for no layout at all! It's all up to the programmer.
        * */

        constraints.gridx = 0;
        constraints.gridy = 0;

        constraints.insets = new Insets(5, 5, 5, 5);
        add(mainPanel, constraints);

        constraints.gridx = 1;
        constraints.gridy = 0;
        add(buttonPanel);


        //Clean up extra space.
        pack();
    }

    //This keeps your initialization method clean and clear, easy, breezy, beautiful, covergirl.
    private void mainPanelClicked(MouseEvent evt) {
        System.out.println("The mouse clicked and it was at: " + evt.getPoint().x + ", " + evt.getPoint().y + " in the mainPanel.");
    }

    public Color getSelectedColor() {
        return buttonPanel.getSelectedColor();
    }

    public void setMainPanelColor(Color color) {
        mainPanel.setBackground(color);
        mainPanel.repaint();
    }
}
