package SwingNOTAP.Frames;

import javax.swing.*;
import java.awt.*;

/**
 * This frame uses the BorderLayout of Java's Swing utilities, another great layout for the swing programmer. I personally
 * find this as a favorite as I generally use different layouts within different components, but use BorderFrame as the
 * layout for my main window due to its simplicity.
 */
public class BorderFrame extends JFrame{

    public BorderFrame() {
        initComponents();
    }

    private void initComponents() {
        //Tell java to exit the program on close.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Set the layout and add some buttons.
        setLayout(new BorderLayout());
        add(new Button("North"), BorderLayout.NORTH);
        add(new Button("South"), BorderLayout.SOUTH);
        add(new Button("East"), BorderLayout.EAST);
        add(new Button("West"), BorderLayout.WEST);
        add(new Button("Center"), BorderLayout.CENTER);

        //Pack up the frame to fit the buttons.
        pack();
    }
}
