package SwingNOTAP.Frames;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

/**
 * This is a more simple swing frame to get used to working in swing.
 */
public class SimpleFrame extends JFrame {

    public SimpleFrame() {
        initComponents();
    }

    /*
    * This method is very simple! It tells Java to close the window and its components when it is closed, thus freeing memory.
    * It also tell Java that it would prefer to be 600 x 600 but it is resizable!
    * Finally it tells Java to fit the window size to the dimension of the frame and all of its components within.
    * */
    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setPreferredSize(new Dimension(600, 600));

        pack();
    }

    /*
    * Here I have overridden the paint method so that everytime repaint() is called, it draws 300 circles in random
    * positions.
    *
    * Note: You HAVE to call repaint for the frame to be redrawn. And you must override the paint() method in JFrames
    * or paintComponent() method in JPanels and other components to properly sketch graphics to the panel or frame. These
    * methods are called by repaint when Java feels it is a good time to paint the screen.
    * */
    @Override
    public void paint(Graphics g) {
        Random random = new Random();
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        for(int i = 0; i < 300; i++) {
            g.setColor(Color.WHITE);
            g.fillOval(random.nextInt(getWidth()), random.nextInt(getHeight()), 3, 3);
        }
    }
}
